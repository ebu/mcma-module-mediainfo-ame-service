"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = handler;
const AWSXRay = require("aws-xray-sdk-core");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const client_lambda_1 = require("@aws-sdk/client-lambda");
const api_1 = require("@mcma/api");
const aws_dynamodb_1 = require("@mcma/aws-dynamodb");
const aws_lambda_worker_invoker_1 = require("@mcma/aws-lambda-worker-invoker");
const aws_api_gateway_1 = require("@mcma/aws-api-gateway");
const core_1 = require("@mcma/core");
const dynamoDBClient = AWSXRay.captureAWSv3Client(new client_dynamodb_1.DynamoDBClient({}));
const lambdaClient = AWSXRay.captureAWSv3Client(new client_lambda_1.LambdaClient({}));
const dbTableProvider = new aws_dynamodb_1.DynamoDbTableProvider({}, dynamoDBClient);
const loggerProvider = new core_1.ConsoleLoggerProvider("mediainfo-ame-service-api-handler");
const workerInvoker = new aws_lambda_worker_invoker_1.LambdaWorkerInvoker(lambdaClient);
const routes = new api_1.DefaultJobRouteCollection(dbTableProvider, workerInvoker);
const restController = new aws_api_gateway_1.ApiGatewayApiController(routes, loggerProvider);
async function handler(event, context) {
    const logger = await loggerProvider.get(context.awsRequestId);
    try {
        logger.functionStart(context.awsRequestId);
        logger.debug(event);
        logger.debug(context);
        return await restController.handleRequest(event, context);
    }
    catch (error) {
        logger.error(error);
        throw error;
    }
    finally {
        logger.functionEnd(context.awsRequestId);
    }
}
