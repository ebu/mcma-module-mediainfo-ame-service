"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mediaInfo = mediaInfo;
exports.extractTechnicalMetadata = extractTechnicalMetadata;
exports.generateFilePrefix = generateFilePrefix;
const util = require("util");
const childProcess = require("child_process");
const client_s3_1 = require("@aws-sdk/client-s3");
const s3_request_presigner_1 = require("@aws-sdk/s3-request-presigner");
const core_1 = require("@mcma/core");
const aws_s3_1 = require("@mcma/aws-s3");
const { OUTPUT_BUCKET, OUTPUT_BUCKET_PREFIX } = process.env;
const execFile = util.promisify(childProcess.execFile);
async function mediaInfo(params) {
    try {
        const { stdout, stderr } = await execFile("/opt/bin/mediainfo", params);
        return { stdout, stderr };
    }
    catch (error) {
        throw new core_1.McmaException("Failed to run media info", error);
    }
}
async function extractTechnicalMetadata(providers, jobAssignmentHelper, ctx) {
    const logger = jobAssignmentHelper.logger;
    const jobInput = jobAssignmentHelper.jobInput;
    logger.info("Execute media info on input file");
    let inputFile = jobInput.inputFile;
    let output;
    if (inputFile.url) {
        logger.info("Obtaining mediainfo output based on url " + inputFile.url);
        output = await mediaInfo(["--Output=EBUCore_JSON", inputFile.url]);
    }
    else {
        throw new core_1.McmaException("Not able to obtain input file");
    }
    logger.info("Check if we have mediaInfo output:");
    logger.info(logger);
    if (!output?.stdout) {
        throw new core_1.McmaException("Failed to obtain mediaInfo stdout");
    }
    const objectKey = generateFilePrefix(inputFile.url) + ".json";
    jobAssignmentHelper.jobOutput.outputFile = await putFile(objectKey, output?.stdout, ctx.s3Client);
    logger.info("Marking JobAssignment as completed");
    await jobAssignmentHelper.complete();
}
async function putFile(objectKey, body, s3Client) {
    await s3Client.send(new client_s3_1.PutObjectCommand({
        Bucket: OUTPUT_BUCKET,
        Key: objectKey,
        Body: body,
    }));
    const command = new client_s3_1.GetObjectCommand({
        Bucket: OUTPUT_BUCKET,
        Key: objectKey,
    });
    return new aws_s3_1.S3Locator({ url: await (0, s3_request_presigner_1.getSignedUrl)(s3Client, command, { expiresIn: 12 * 3600 }) });
}
function generateFilePrefix(url) {
    let filename = decodeURIComponent(new URL(url).pathname);
    let pos = filename.lastIndexOf("/");
    if (pos >= 0) {
        filename = filename.substring(pos + 1);
    }
    pos = filename.lastIndexOf(".");
    if (pos >= 0) {
        filename = filename.substring(0, pos);
    }
    return `${OUTPUT_BUCKET_PREFIX}${new Date().toISOString().substring(0, 19).replace(/[:]/g, "-")}/${filename}`;
}
