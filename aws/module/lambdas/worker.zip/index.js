"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.handler = handler;
const AWSXRay = require("aws-xray-sdk-core");
const client_cloudwatch_logs_1 = require("@aws-sdk/client-cloudwatch-logs");
const client_dynamodb_1 = require("@aws-sdk/client-dynamodb");
const client_s3_1 = require("@aws-sdk/client-s3");
const client_1 = require("@mcma/client");
const worker_1 = require("@mcma/worker");
const aws_dynamodb_1 = require("@mcma/aws-dynamodb");
const aws_logger_1 = require("@mcma/aws-logger");
const aws_client_1 = require("@mcma/aws-client");
const core_1 = require("@mcma/core");
const operations_1 = require("./operations");
const cloudWatchLogsClient = AWSXRay.captureAWSv3Client(new client_cloudwatch_logs_1.CloudWatchLogsClient({}));
const dynamoDBClient = AWSXRay.captureAWSv3Client(new client_dynamodb_1.DynamoDBClient({}));
const s3Client = AWSXRay.captureAWSv3Client(new client_s3_1.S3Client({}));
const authProvider = new client_1.AuthProvider().add((0, aws_client_1.awsV4Auth)());
const dbTableProvider = new aws_dynamodb_1.DynamoDbTableProvider({}, dynamoDBClient);
const loggerProvider = new aws_logger_1.AwsCloudWatchLoggerProvider("mediainfo-ame-service-worker", (0, aws_logger_1.getLogGroupName)(), cloudWatchLogsClient);
const resourceManagerProvider = new client_1.ResourceManagerProvider(authProvider);
const providerCollection = new worker_1.ProviderCollection({
    authProvider,
    dbTableProvider,
    loggerProvider,
    resourceManagerProvider
});
const processJobAssignmentOperation = new worker_1.ProcessJobAssignmentOperation(core_1.AmeJob)
    .addProfile("ExtractTechnicalMetadata", operations_1.extractTechnicalMetadata);
const worker = new worker_1.Worker(providerCollection)
    .addOperation(processJobAssignmentOperation);
async function handler(event, context) {
    const logger = await loggerProvider.get(context.awsRequestId, event.tracker);
    try {
        logger.functionStart(context.awsRequestId);
        logger.debug(event);
        logger.debug(context);
        await worker.doWork(new worker_1.WorkerRequest(event, logger), {
            awsRequestId: context.awsRequestId,
            s3Client,
        });
    }
    catch (error) {
        logger.error("Error occurred when handling operation '" + event.operationName + "'");
        logger.error(error.toString());
    }
    finally {
        logger.functionEnd(context.awsRequestId);
        await loggerProvider.flush();
    }
}
